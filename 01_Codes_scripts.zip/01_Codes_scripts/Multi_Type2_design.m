%============== UFSC - Federal University of Santa Catarina ===================
%============== UNESP- State University of São Paulo ==========================
% Author: G2 Power. 
% Date: October 2025
% Title: CPT-based Multifunctional Grid-Tied Inverter with Type II Controller

close all
clear all
clc
format long

f = 50; 
T = 1/f;
Vdc = 225; 
Lf = 4.8e-3;
Rf = 0.01;
Hi = 1/10;
Fs = 25e3;
fc = Fs/10;
MFd = 60;

ts = 1/Fs;

s = tf('s');
Gi = Vdc / (s*Lf + Rf);

FTMAu = Gi*Hi;

opts = bodeoptions('cstprefs');
opts.FreqUnits = 'Hz';

figure
bode(FTMAu,opts)
title('Uncontrolled Open Loop Transfer Function');
xlim([0.001 1e5]);
grid

%Design of the type 2 current controller
inst = evalfr(FTMAu, 2*pi*fc*j);
fase_fc = rad2deg(phase(inst));

ganho_fc = mag2db(abs(inst));
ganho_real = 10^(abs(ganho_fc/20));

alpha = MFd - fase_fc - 90;

K2 = tand(alpha/2 + 45);

Prod = 1/(2*pi*fc*ganho_real*K2);
C2 = 100e-9;
R1 = Prod/C2;
C1 = C2*((K2^2)-1);
R2 = K2/(2*pi*fc*C1);

Ctipo2 = (1+s*R2*C1)/(s*R1*(C1+C2+s*R2*C1*C2));

figure
bode(Ctipo2,opts)
title('Designed controller');
xlim([0.001 1e5]);
grid

FTMAc = FTMAu*Ctipo2;
figure
bode(FTMAc,opts)
xlim([0.001 1e5]);
title('Controlled Open Loop Transfer Function');
grid

inst2 = evalfr(FTMAc, 2*pi*fc*j);
MF_obitda = rad2deg(phase(inst2))+180;

ganho_obtido = mag2db(abs(inst2));
ganho_real_obitdo = 10^(abs(ganho_obtido/20));

%Discretization of type 2 controller

beta = 4*R1*R2*C1*C2 + 2*ts*R1*(C1+C2);

b0 = (ts^2 + 2*ts*C1*R2)/beta;
b1 = (2*ts^2)/beta;
b2 = (ts^2 - 2*ts*C1*R2)/beta;

a0 = 1;
a1 = (-8*R1*R2*C1*C2)/beta;
a2 = (4*R1*R2*C1*C2 - 2*ts*R1*(C1+C2))/beta;

b = [b0 b1 b2];
a = [a0 a1 a2];

H = tf(b,a,ts);

figure
bode(H,opts)
hold
bode(Ctipo2,opts)
grid
title('Comparison between the analog and digital controllers');

FTMF = FTMAc/(1+FTMAc);
figure
bode(FTMF,opts)
grid
title('Bode Diagram of the Closed-Loop Transfer Function');





